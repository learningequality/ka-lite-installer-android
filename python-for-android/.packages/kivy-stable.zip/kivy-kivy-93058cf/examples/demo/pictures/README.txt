Pictures
========

A very simple image browser, supporting the reading only from images/
directory right now.
So put any images files inside images/ directory, and start the app !

Android
-------

You can copy/paste this directory into /sdcard/kivy/pictures in your
android device.


Licences
--------

* faust_github.jpg: lucie's cat accepted to share his face
* 5552597274_de8b3fb5d2_b.jpg: http://www.flickr.com/photos/chialin-gallery/5552597274/sizes/l/
* 5509213687_ffd18df0b9_b.jpg: http://www.flickr.com/photos/orsomk/5509213687/sizes/l/
